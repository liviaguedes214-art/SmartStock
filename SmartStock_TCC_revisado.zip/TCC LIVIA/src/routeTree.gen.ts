import { Route as rootRouteImport } from './routes/__root'
import { Route as LoginRouteImport } from './routes/login'
import { Route as AppRouteImport } from './routes/_app'
import { Route as IndexRouteImport } from './routes/index'
import { Route as AppUsuariosRouteImport } from './routes/_app.usuarios'
import { Route as AppTutorialRouteImport } from './routes/_app.tutorial'
import { Route as AppScannerRouteImport } from './routes/_app.scanner'
import { Route as AppRelatoriosRouteImport } from './routes/_app.relatorios'
import { Route as AppProdutosRouteImport } from './routes/_app.produtos'
import { Route as AppMovimentacoesRouteImport } from './routes/_app.movimentacoes'
import { Route as AppIaRouteImport } from './routes/_app.ia'
import { Route as AppDashboardRouteImport } from './routes/_app.dashboard'
import { Route as AppAlertasRouteImport } from './routes/_app.alertas'

const LoginRoute = LoginRouteImport.update({
  id: '/login',
  path: '/login',
  getParentRoute: () => rootRouteImport,
} as any)
const AppRoute = AppRouteImport.update({
  id: '/_app',
  getParentRoute: () => rootRouteImport,
} as any)
const IndexRoute = IndexRouteImport.update({
  id: '/',
  path: '/',
  getParentRoute: () => rootRouteImport,
} as any)
const AppUsuariosRoute = AppUsuariosRouteImport.update({
  id: '/usuarios',
  path: '/usuarios',
  getParentRoute: () => AppRoute,
} as any)
const AppTutorialRoute = AppTutorialRouteImport.update({
  id: '/tutorial',
  path: '/tutorial',
  getParentRoute: () => AppRoute,
} as any)
const AppScannerRoute = AppScannerRouteImport.update({
  id: '/scanner',
  path: '/scanner',
  getParentRoute: () => AppRoute,
} as any)
const AppRelatoriosRoute = AppRelatoriosRouteImport.update({
  id: '/relatorios',
  path: '/relatorios',
  getParentRoute: () => AppRoute,
} as any)
const AppProdutosRoute = AppProdutosRouteImport.update({
  id: '/produtos',
  path: '/produtos',
  getParentRoute: () => AppRoute,
} as any)
const AppMovimentacoesRoute = AppMovimentacoesRouteImport.update({
  id: '/movimentacoes',
  path: '/movimentacoes',
  getParentRoute: () => AppRoute,
} as any)
const AppIaRoute = AppIaRouteImport.update({
  id: '/ia',
  path: '/ia',
  getParentRoute: () => AppRoute,
} as any)
const AppDashboardRoute = AppDashboardRouteImport.update({
  id: '/dashboard',
  path: '/dashboard',
  getParentRoute: () => AppRoute,
} as any)
const AppAlertasRoute = AppAlertasRouteImport.update({
  id: '/alertas',
  path: '/alertas',
  getParentRoute: () => AppRoute,
} as any)

export interface FileRoutesByFullPath {
  '/': typeof IndexRoute
  '/login': typeof LoginRoute
  '/alertas': typeof AppAlertasRoute
  '/dashboard': typeof AppDashboardRoute
  '/ia': typeof AppIaRoute
  '/movimentacoes': typeof AppMovimentacoesRoute
  '/produtos': typeof AppProdutosRoute
  '/relatorios': typeof AppRelatoriosRoute
  '/scanner': typeof AppScannerRoute
  '/tutorial': typeof AppTutorialRoute
  '/usuarios': typeof AppUsuariosRoute
}
export interface FileRoutesByTo {
  '/': typeof IndexRoute
  '/login': typeof LoginRoute
  '/alertas': typeof AppAlertasRoute
  '/dashboard': typeof AppDashboardRoute
  '/ia': typeof AppIaRoute
  '/movimentacoes': typeof AppMovimentacoesRoute
  '/produtos': typeof AppProdutosRoute
  '/relatorios': typeof AppRelatoriosRoute
  '/scanner': typeof AppScannerRoute
  '/tutorial': typeof AppTutorialRoute
  '/usuarios': typeof AppUsuariosRoute
}
export interface FileRoutesById {
  __root__: typeof rootRouteImport
  '/': typeof IndexRoute
  '/_app': typeof AppRouteWithChildren
  '/login': typeof LoginRoute
  '/_app/alertas': typeof AppAlertasRoute
  '/_app/dashboard': typeof AppDashboardRoute
  '/_app/ia': typeof AppIaRoute
  '/_app/movimentacoes': typeof AppMovimentacoesRoute
  '/_app/produtos': typeof AppProdutosRoute
  '/_app/relatorios': typeof AppRelatoriosRoute
  '/_app/scanner': typeof AppScannerRoute
  '/_app/tutorial': typeof AppTutorialRoute
  '/_app/usuarios': typeof AppUsuariosRoute
}
export interface FileRouteTypes {
  fileRoutesByFullPath: FileRoutesByFullPath
  fullPaths:
    | '/'
    | '/login'
    | '/alertas'
    | '/dashboard'
    | '/ia'
    | '/movimentacoes'
    | '/produtos'
    | '/relatorios'
    | '/scanner'
    | '/tutorial'
    | '/usuarios'
  fileRoutesByTo: FileRoutesByTo
  to:
    | '/'
    | '/login'
    | '/alertas'
    | '/dashboard'
    | '/ia'
    | '/movimentacoes'
    | '/produtos'
    | '/relatorios'
    | '/scanner'
    | '/tutorial'
    | '/usuarios'
  id:
    | '__root__'
    | '/'
    | '/_app'
    | '/login'
    | '/_app/alertas'
    | '/_app/dashboard'
    | '/_app/ia'
    | '/_app/movimentacoes'
    | '/_app/produtos'
    | '/_app/relatorios'
    | '/_app/scanner'
    | '/_app/tutorial'
    | '/_app/usuarios'
  fileRoutesById: FileRoutesById
}
export interface RootRouteChildren {
  IndexRoute: typeof IndexRoute
  AppRoute: typeof AppRouteWithChildren
  LoginRoute: typeof LoginRoute
}

declare module '@tanstack/react-router' {
  interface FileRoutesByPath {
    '/login': {
      id: '/login'
      path: '/login'
      fullPath: '/login'
      preLoaderRoute: typeof LoginRouteImport
      parentRoute: typeof rootRouteImport
    }
    '/_app': {
      id: '/_app'
      path: ''
      fullPath: '/'
      preLoaderRoute: typeof AppRouteImport
      parentRoute: typeof rootRouteImport
    }
    '/': {
      id: '/'
      path: '/'
      fullPath: '/'
      preLoaderRoute: typeof IndexRouteImport
      parentRoute: typeof rootRouteImport
    }
    '/_app/usuarios': {
      id: '/_app/usuarios'
      path: '/usuarios'
      fullPath: '/usuarios'
      preLoaderRoute: typeof AppUsuariosRouteImport
      parentRoute: typeof AppRoute
    }
    '/_app/tutorial': {
      id: '/_app/tutorial'
      path: '/tutorial'
      fullPath: '/tutorial'
      preLoaderRoute: typeof AppTutorialRouteImport
      parentRoute: typeof AppRoute
    }
    '/_app/scanner': {
      id: '/_app/scanner'
      path: '/scanner'
      fullPath: '/scanner'
      preLoaderRoute: typeof AppScannerRouteImport
      parentRoute: typeof AppRoute
    }
    '/_app/relatorios': {
      id: '/_app/relatorios'
      path: '/relatorios'
      fullPath: '/relatorios'
      preLoaderRoute: typeof AppRelatoriosRouteImport
      parentRoute: typeof AppRoute
    }
    '/_app/produtos': {
      id: '/_app/produtos'
      path: '/produtos'
      fullPath: '/produtos'
      preLoaderRoute: typeof AppProdutosRouteImport
      parentRoute: typeof AppRoute
    }
    '/_app/movimentacoes': {
      id: '/_app/movimentacoes'
      path: '/movimentacoes'
      fullPath: '/movimentacoes'
      preLoaderRoute: typeof AppMovimentacoesRouteImport
      parentRoute: typeof AppRoute
    }
    '/_app/ia': {
      id: '/_app/ia'
      path: '/ia'
      fullPath: '/ia'
      preLoaderRoute: typeof AppIaRouteImport
      parentRoute: typeof AppRoute
    }
    '/_app/dashboard': {
      id: '/_app/dashboard'
      path: '/dashboard'
      fullPath: '/dashboard'
      preLoaderRoute: typeof AppDashboardRouteImport
      parentRoute: typeof AppRoute
    }
    '/_app/alertas': {
      id: '/_app/alertas'
      path: '/alertas'
      fullPath: '/alertas'
      preLoaderRoute: typeof AppAlertasRouteImport
      parentRoute: typeof AppRoute
    }
  }
}

interface AppRouteChildren {
  AppAlertasRoute: typeof AppAlertasRoute
  AppDashboardRoute: typeof AppDashboardRoute
  AppIaRoute: typeof AppIaRoute
  AppMovimentacoesRoute: typeof AppMovimentacoesRoute
  AppProdutosRoute: typeof AppProdutosRoute
  AppRelatoriosRoute: typeof AppRelatoriosRoute
  AppScannerRoute: typeof AppScannerRoute
  AppTutorialRoute: typeof AppTutorialRoute
  AppUsuariosRoute: typeof AppUsuariosRoute
}

const AppRouteChildren: AppRouteChildren = {
  AppAlertasRoute: AppAlertasRoute,
  AppDashboardRoute: AppDashboardRoute,
  AppIaRoute: AppIaRoute,
  AppMovimentacoesRoute: AppMovimentacoesRoute,
  AppProdutosRoute: AppProdutosRoute,
  AppRelatoriosRoute: AppRelatoriosRoute,
  AppScannerRoute: AppScannerRoute,
  AppTutorialRoute: AppTutorialRoute,
  AppUsuariosRoute: AppUsuariosRoute,
}

const AppRouteWithChildren = AppRoute._addFileChildren(AppRouteChildren)

const rootRouteChildren: RootRouteChildren = {
  IndexRoute: IndexRoute,
  AppRoute: AppRouteWithChildren,
  LoginRoute: LoginRoute,
}
export const routeTree = rootRouteImport
  ._addFileChildren(rootRouteChildren)
  ._addFileTypes<FileRouteTypes>()

import type { getRouter } from './router.tsx'
import type { startInstance } from './start.ts'
declare module '@tanstack/react-start' {
  interface Register {
    ssr: true
    router: Awaited<ReturnType<typeof getRouter>>
    config: Awaited<ReturnType<typeof startInstance.getOptions>>
  }
}
