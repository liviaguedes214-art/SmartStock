import { Link, useRouterState } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth-context";
import {
  Boxes, LayoutDashboard, Package, ArrowLeftRight, Bell, FileBarChart,
  ScanLine, Sparkles, Users, BookOpen, LogOut, Menu, X,
} from "lucide-react";
import { useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface NavItem { to: string; label: string; icon: ReactNode; adminOnly?: boolean }

const NAV: NavItem[] = [
  { to: "/dashboard", label: "Dashboard", icon: <LayoutDashboard className="h-4 w-4" /> },
  { to: "/produtos", label: "Produtos", icon: <Package className="h-4 w-4" /> },
  { to: "/movimentacoes", label: "Movimentações", icon: <ArrowLeftRight className="h-4 w-4" /> },
  { to: "/alertas", label: "Alertas", icon: <Bell className="h-4 w-4" /> },
  { to: "/relatorios", label: "Relatórios", icon: <FileBarChart className="h-4 w-4" /> },
  { to: "/scanner", label: "Scanner", icon: <ScanLine className="h-4 w-4" /> },
  { to: "/ia", label: "Assistente IA", icon: <Sparkles className="h-4 w-4" /> },
  { to: "/usuarios", label: "Usuários", icon: <Users className="h-4 w-4" />, adminOnly: true },
  { to: "/tutorial", label: "Tutorial", icon: <BookOpen className="h-4 w-4" /> },
];

export function AppShell({ children }: { children: ReactNode }) {
  const { profile, role, signOut, isAdmin } = useAuth();
  const [open, setOpen] = useState(false);
  const path = useRouterState({ select: (s) => s.location.pathname });

  const items = NAV.filter((n) => !n.adminOnly || isAdmin);
  const initials = (profile?.full_name || profile?.email || "U").split(" ").map((s) => s[0]).slice(0, 2).join("").toUpperCase();

  return (
    <div className="min-h-screen flex bg-background text-foreground">
      {/* Mobile top bar */}
      <header className="lg:hidden fixed top-0 inset-x-0 z-40 h-14 border-b border-border bg-sidebar/95 backdrop-blur flex items-center justify-between px-4">
        <Link to="/dashboard" className="flex items-center gap-2">
          <div className="rounded-lg bg-gradient-primary p-1.5"><Boxes className="h-4 w-4 text-primary-foreground" /></div>
          <span className="font-semibold">SmartStock</span>
        </Link>
        <Button size="icon" variant="ghost" onClick={() => setOpen((v) => !v)}>
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </header>

      {/* Sidebar */}
      <aside className={cn(
        "fixed lg:sticky top-0 z-30 h-screen w-64 shrink-0 bg-sidebar border-r border-sidebar-border flex flex-col",
        "transition-transform duration-200",
        open ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
      )}>
        <div className="hidden lg:flex items-center gap-3 px-5 h-16 border-b border-sidebar-border">
          <div className="rounded-xl bg-gradient-primary p-2 shadow-glow"><Boxes className="h-5 w-5 text-primary-foreground" /></div>
          <div className="leading-tight">
            <div className="font-semibold tracking-tight">SmartStock</div>
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Inventory OS</div>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto p-3 mt-14 lg:mt-0 space-y-1">
          {items.map((n) => {
            const active = path === n.to || (n.to !== "/dashboard" && path.startsWith(n.to));
            return (
              <Link
                key={n.to}
                to={n.to}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                  active
                    ? "bg-gradient-primary text-primary-foreground shadow-glow"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-foreground",
                )}
              >
                {n.icon}
                <span>{n.label}</span>
              </Link>
            );
          })}
        </nav>
        <div className="p-3 border-t border-sidebar-border">
          <div className="flex items-center gap-3 rounded-lg p-2">
            <Avatar className="h-9 w-9"><AvatarFallback className="bg-primary/20 text-primary">{initials}</AvatarFallback></Avatar>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">{profile?.full_name || profile?.email}</div>
              <Badge variant="outline" className="mt-0.5 text-[10px] py-0 h-4 border-primary/30 text-primary">
                {role === "admin" ? "Administrador" : "Funcionário"}
              </Badge>
            </div>
            <Button size="icon" variant="ghost" onClick={signOut} title="Sair">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </aside>

      {open && <div className="fixed inset-0 z-20 bg-black/50 lg:hidden" onClick={() => setOpen(false)} />}

      <main className="flex-1 min-w-0 pt-14 lg:pt-0">
        <div className="p-4 sm:p-6 lg:p-8 max-w-[1600px] mx-auto">{children}</div>
      </main>
    </div>
  );
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight">{title}</h1>
        {subtitle && <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}