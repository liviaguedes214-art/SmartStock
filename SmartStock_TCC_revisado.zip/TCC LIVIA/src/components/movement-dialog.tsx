import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";

type MovementType = "entrada" | "saida" | "perda";

export function MovementDialog({
  productId, open, onOpenChange, onSaved,
}: {
  productId: string | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onSaved?: () => void;
}) {
  const { user } = useAuth();
  const [type, setType] = useState<MovementType>("saida");
  const [quantity, setQuantity] = useState(1);
  const [unitPrice, setUnitPrice] = useState(0);
  const [reason, setReason] = useState("");
  const [saving, setSaving] = useState(false);
  const [product, setProduct] = useState<{ name: string; price: number; quantity: number } | null>(null);

  useEffect(() => {
    if (open && productId) {
      supabase.from("products").select("name, price, quantity").eq("id", productId).maybeSingle().then(({ data }) => {
        if (data) {
          setProduct({ name: data.name, price: Number(data.price), quantity: data.quantity });
          setUnitPrice(Number(data.price));
          setQuantity(1);
          setReason("");
          setType("saida");
        }
      });
    }
  }, [open, productId]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productId || !user || !product) return;

    if (!Number.isInteger(quantity) || quantity < 1) {
      toast.error("Quantidade inválida", { description: "Informe um número inteiro maior que zero." });
      return;
    }

    if (!Number.isFinite(unitPrice) || unitPrice < 0) {
      toast.error("Preço inválido", { description: "Informe um preço igual ou maior que zero." });
      return;
    }

    if (type !== "entrada" && quantity > product.quantity) {
      toast.error("Estoque insuficiente", {
        description: `Há apenas ${product.quantity} unidade(s) disponível(is).`,
      });
      return;
    }

    setSaving(true);
    const total = Number(quantity) * Number(unitPrice);
    const { error } = await supabase.from("movements").insert({
      product_id: productId,
      type,
      quantity: Number(quantity),
      unit_price: Number(unitPrice),
      total,
      reason: reason || null,
      created_by: user.id,
    });
    setSaving(false);
    if (error) return toast.error("Erro ao registrar", { description: error.message });
    toast.success("Movimentação registrada");
    onOpenChange(false);
    onSaved?.();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Registrar movimentação</DialogTitle>
          <DialogDescription>
            {product ? <>Produto: <span className="font-medium text-foreground">{product.name}</span> · Estoque atual: <span className="font-medium text-foreground">{product.quantity}</span></> : "Carregando…"}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5">
            <Label className="text-xs">Tipo</Label>
            <Select value={type} onValueChange={(v) => setType(v as MovementType)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="entrada">Entrada (compra/reposição)</SelectItem>
                <SelectItem value="saida">Saída (venda)</SelectItem>
                <SelectItem value="perda">Perda (vencido/dano)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label className="text-xs">Quantidade</Label>
              <Input type="number" min={1} step={1} value={quantity} onChange={(e) => setQuantity(Number(e.target.value))} required />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Preço unitário (R$)</Label>
              <Input type="number" step="0.01" min={0} value={unitPrice} onChange={(e) => setUnitPrice(Number(e.target.value))} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Observação</Label>
            <Textarea rows={2} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Opcional" />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={saving || !product}>{saving && <Loader2 className="h-4 w-4 animate-spin" />} Registrar</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}