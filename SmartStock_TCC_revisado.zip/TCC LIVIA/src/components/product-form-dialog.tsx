import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CATEGORIES, generateProductCode, type CategoryValue } from "@/lib/constants";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export interface ProductRow {
  id?: string;
  code: string;
  name: string;
  category: string;
  quantity: number;
  min_quantity: number;
  price: number;
  cost_price: number;
  supplier: string | null;
  expiry_date: string | null;
  location: string | null;
  description: string | null;
}

export function ProductFormDialog({
  open, onOpenChange, initial, onSaved,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  initial?: Partial<ProductRow>;
  onSaved?: () => void;
}) {
  const [form, setForm] = useState<ProductRow>(empty());
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) setForm({ ...empty(), ...initial, code: initial?.code || generateProductCode() } as ProductRow);
  }, [open, initial]);

  const update = <K extends keyof ProductRow>(k: K, v: ProductRow[K]) => setForm((p) => ({ ...p, [k]: v }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const payload = {
      code: form.code.trim(),
      name: form.name.trim(),
      category: form.category as CategoryValue,
      quantity: Number(form.quantity) || 0,
      min_quantity: Number(form.min_quantity) || 0,
      price: Number(form.price) || 0,
      cost_price: Number(form.cost_price) || 0,
      supplier: form.supplier || null,
      expiry_date: form.expiry_date || null,
      location: form.location || null,
      description: form.description || null,
    };
    const res = initial?.id
      ? await supabase.from("products").update(payload).eq("id", initial.id)
      : await supabase.from("products").insert(payload);
    setSaving(false);
    if (res.error) {
      toast.error("Erro ao salvar", { description: res.error.message });
      return;
    }
    toast.success(initial?.id ? "Produto atualizado" : "Produto cadastrado");
    onOpenChange(false);
    onSaved?.();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{initial?.id ? "Editar produto" : "Novo produto"}</DialogTitle>
          <DialogDescription>Preencha as informações do produto. Apenas administradores podem cadastrar ou editar.</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
          <Field label="Código" required>
            <Input value={form.code} onChange={(e) => update("code", e.target.value)} required />
          </Field>
          <Field label="Nome" required>
            <Input value={form.name} onChange={(e) => update("name", e.target.value)} required />
          </Field>
          <Field label="Categoria">
            <Select value={form.category} onValueChange={(v) => update("category", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Fornecedor">
            <Input value={form.supplier ?? ""} onChange={(e) => update("supplier", e.target.value)} />
          </Field>
          <Field label="Quantidade">
            <Input type="number" min={0} value={form.quantity} onChange={(e) => update("quantity", Number(e.target.value))} />
          </Field>
          <Field label="Estoque mínimo">
            <Input type="number" min={0} value={form.min_quantity} onChange={(e) => update("min_quantity", Number(e.target.value))} />
          </Field>
          <Field label="Preço de venda (R$)">
            <Input type="number" step="0.01" min={0} value={form.price} onChange={(e) => update("price", Number(e.target.value))} />
          </Field>
          <Field label="Preço de custo (R$)">
            <Input type="number" step="0.01" min={0} value={form.cost_price} onChange={(e) => update("cost_price", Number(e.target.value))} />
          </Field>
          <Field label="Validade">
            <Input type="date" value={form.expiry_date ?? ""} onChange={(e) => update("expiry_date", e.target.value)} />
          </Field>
          <Field label="Localização no estoque">
            <Input value={form.location ?? ""} onChange={(e) => update("location", e.target.value)} placeholder="Ex: Prateleira A2" />
          </Field>
          <Field label="Descrição" full>
            <Textarea rows={3} value={form.description ?? ""} onChange={(e) => update("description", e.target.value)} />
          </Field>
          <DialogFooter className="sm:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={saving}>{saving && <Loader2 className="h-4 w-4 animate-spin" />} Salvar</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, children, required, full }: { label: string; children: React.ReactNode; required?: boolean; full?: boolean }) {
  return (
    <div className={`space-y-1.5 ${full ? "sm:col-span-2" : ""}`}>
      <Label className="text-xs">{label}{required && <span className="text-destructive"> *</span>}</Label>
      {children}
    </div>
  );
}

function empty(): ProductRow {
  return {
    code: "", name: "", category: "outros",
    quantity: 0, min_quantity: 5, price: 0, cost_price: 0,
    supplier: "", expiry_date: "", location: "", description: "",
  };
}