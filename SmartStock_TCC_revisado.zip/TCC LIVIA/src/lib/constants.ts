export const CATEGORIES = [
  { value: "bebidas", label: "Bebidas" },
  { value: "alimentos", label: "Alimentos" },
  { value: "limpeza", label: "Limpeza" },
  { value: "higiene", label: "Higiene" },
  { value: "eletronicos", label: "Eletrônicos" },
  { value: "outros", label: "Outros" },
] as const;

export type CategoryValue = (typeof CATEGORIES)[number]["value"];

export const CATEGORY_LABEL: Record<CategoryValue, string> = Object.fromEntries(
  CATEGORIES.map((c) => [c.value, c.label]),
) as Record<CategoryValue, string>;

export const MOVEMENT_LABEL = {
  entrada: "Entrada",
  saida: "Saída",
  perda: "Perda",
} as const;

export function generateProductCode() {
  const t = Date.now().toString(36).toUpperCase().slice(-6);
  const r = Math.random().toString(36).toUpperCase().slice(-3);
  return `SS-${t}${r}`;
}