import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1/chat/completions";

function getApiKey() {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("LOVABLE_API_KEY não configurada.");
  return key;
}

async function chat(messages: Array<{ role: string; content: unknown }>, model = "google/gemini-2.5-flash") {
  const res = await fetch(GATEWAY_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": getApiKey(),
    },
    body: JSON.stringify({ model, messages }),
  });
  if (res.status === 402) throw new Error("Créditos esgotados. Adicione créditos no workspace.");
  if (res.status === 429) throw new Error("Limite de uso atingido. Tente novamente em instantes.");
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Erro do gateway (${res.status}): ${text.slice(0, 200)}`);
  }
  const json = await res.json();
  return (json.choices?.[0]?.message?.content as string) ?? "";
}

export const suggestReposition = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const [{ data: products }, { data: moves }] = await Promise.all([
      supabase.from("products").select("id, name, code, category, quantity, min_quantity, price, cost_price, expiry_date").limit(500),
      supabase.from("movements").select("product_id, type, quantity, created_at").order("created_at", { ascending: false }).limit(500),
    ]);

    const summary = {
      products: (products ?? []).map((p) => ({
        nome: p.name, codigo: p.code, categoria: p.category,
        estoque: p.quantity, minimo: p.min_quantity,
        validade: p.expiry_date,
      })),
      ultimas_movimentacoes: (moves ?? []).slice(0, 60),
    };

    const prompt = `Você é um especialista em gestão de estoque para um sistema chamado SmartStock. Analise os dados abaixo e responda em português brasileiro, de forma direta e profissional, com:

1. **Top 5 produtos para repor imediatamente** (com justificativa baseada em estoque atual vs. mínimo e velocidade de saída).
2. **Produtos com risco de vencimento** que devem ser priorizados em vendas/promoções.
3. **Padrões de consumo** identificados (categorias mais vendidas, sazonalidade visível).
4. **Sugestões práticas** para reduzir perdas e melhorar giro.

Use markdown com títulos e listas. Seja conciso.

Dados:
\`\`\`json
${JSON.stringify(summary).slice(0, 12000)}
\`\`\``;

    const answer = await chat([
      { role: "system", content: "Você é um consultor sênior de gestão de estoque." },
      { role: "user", content: prompt },
    ]);
    return { answer };
  });

export const recognizeProductImage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ imageDataUrl: z.string().min(20) }).parse(data))
  .handler(async ({ data }) => {
    const answer = await chat([
      { role: "system", content: "Você identifica produtos comerciais a partir de fotos para cadastro em sistemas de estoque." },
      { role: "user", content: [
        { type: "text", text: "Identifique o produto na imagem. Responda em JSON com as chaves: nome (string), categoria (uma de: bebidas, alimentos, limpeza, higiene, eletronicos, outros), descricao (string curta). Apenas o JSON, sem markdown." },
        { type: "image_url", image_url: { url: data.imageDataUrl } },
      ] },
    ], "google/gemini-2.5-flash");

    let parsed: { nome?: string; categoria?: string; descricao?: string } = {};
    try {
      const cleaned = answer.replace(/^```json\s*|\s*```$/g, "").trim();
      parsed = JSON.parse(cleaned);
    } catch {
      parsed = { descricao: answer };
    }
    return parsed;
  });