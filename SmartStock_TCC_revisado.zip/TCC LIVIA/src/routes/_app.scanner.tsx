import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScanLine, Play, Square, Package } from "lucide-react";
import { toast } from "sonner";
import { formatCurrency } from "@/lib/format";
import type { Html5Qrcode } from "html5-qrcode";

export const Route = createFileRoute("/_app/scanner")({
  head: () => ({ meta: [{ title: "Scanner — SmartStock" }] }),
  component: ScannerPage,
});

interface FoundProduct { id: string; name: string; code: string; quantity: number; price: number }

function ScannerPage() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scanning, setScanning] = useState(false);
  const [lastCode, setLastCode] = useState<string | null>(null);
  const [found, setFound] = useState<FoundProduct | null>(null);
  const [notFoundCode, setNotFoundCode] = useState<string | null>(null);
  const scannerRef = useRef<Html5Qrcode | null>(null);

  const start = async () => {
    if (scanning) return;
    setFound(null); setNotFoundCode(null);
    const { Html5Qrcode } = await import("html5-qrcode");
    const id = "smartstock-reader";
    if (containerRef.current && !document.getElementById(id)) {
      const el = document.createElement("div");
      el.id = id;
      containerRef.current.appendChild(el);
    }
    const scanner = new Html5Qrcode(id);
    scannerRef.current = scanner;
    try {
      await scanner.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: { width: 260, height: 180 } },
        async (decodedText: string) => {
          setLastCode(decodedText);
          const { data } = await supabase.from("products").select("id, name, code, quantity, price").or(`code.eq.${decodedText},name.ilike.%${decodedText}%`).limit(1).maybeSingle();
          if (data) {
            setFound(data as FoundProduct);
            setNotFoundCode(null);
            toast.success(`Produto encontrado: ${data.name}`);
          } else {
            setFound(null);
            setNotFoundCode(decodedText);
          }
          stop();
        },
        () => { /* ignore per-frame errors */ },
      );
      setScanning(true);
    } catch (err) {
      toast.error("Não foi possível abrir a câmera", { description: String(err) });
    }
  };

  const stop = async () => {
    const scanner = scannerRef.current;
    if (scanner) {
      try { await scanner.stop(); await scanner.clear(); } catch { /* noop */ }
      scannerRef.current = null;
    }
    setScanning(false);
  };

  useEffect(() => () => { stop(); }, []);

  return (
    <div className="space-y-6">
      <PageHeader title="Scanner" subtitle="Leia códigos de barras e QR codes pela câmera" />
      <Card className="border-border/60">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ScanLine className="h-4 w-4 text-primary" /> Câmera
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="aspect-video w-full max-w-xl mx-auto rounded-xl border border-border/60 bg-card/60 overflow-hidden grid place-items-center">
            <div ref={containerRef} className="w-full h-full" />
            {!scanning && <p className="text-sm text-muted-foreground">Clique em iniciar para ativar a câmera.</p>}
          </div>
          <div className="flex gap-2 justify-center">
            {!scanning ? (
              <Button onClick={start}><Play className="h-4 w-4" /> Iniciar scanner</Button>
            ) : (
              <Button variant="outline" onClick={stop}><Square className="h-4 w-4" /> Parar</Button>
            )}
          </div>
          {lastCode && (
            <div className="text-center text-sm">
              Último código lido: <Badge variant="outline" className="font-mono">{lastCode}</Badge>
            </div>
          )}
        </CardContent>
      </Card>

      {found && (
        <Card className="border-primary/40">
          <CardContent className="p-5 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-primary/20 text-primary p-2"><Package className="h-5 w-5" /></div>
              <div>
                <div className="font-semibold">{found.name}</div>
                <div className="text-xs text-muted-foreground font-mono">{found.code}</div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm">{found.quantity} em estoque</div>
              <div className="text-xs text-muted-foreground">{formatCurrency(found.price)}</div>
            </div>
            <Link to="/produtos"><Button variant="outline">Abrir produto</Button></Link>
          </CardContent>
        </Card>
      )}
      {notFoundCode && (
        <Card className="border-warning/40">
          <CardContent className="p-5 text-sm">
            Código <span className="font-mono">{notFoundCode}</span> não encontrado no catálogo. Cadastre um novo produto com este código em Produtos.
          </CardContent>
        </Card>
      )}
    </div>
  );
}