import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Boxes, Package, ArrowLeftRight, Bell, FileBarChart, ScanLine, Sparkles, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/_app/tutorial")({
  head: () => ({ meta: [{ title: "Tutorial — SmartStock" }] }),
  component: TutorialPage,
});

const STEPS = [
  { icon: <Package className="h-5 w-5" />, title: "Cadastre seus produtos", body: "Acesse Produtos → Novo produto. O código é gerado automaticamente. Defina estoque mínimo e validade para ativar os alertas." },
  { icon: <ArrowLeftRight className="h-5 w-5" />, title: "Registre entradas e saídas", body: "Clique no ícone de movimentação em qualquer produto. Escolha entrada (compra), saída (venda) ou perda. O estoque é atualizado automaticamente." },
  { icon: <Bell className="h-5 w-5" />, title: "Acompanhe alertas", body: "A página Alertas mostra produtos com estoque zerado, baixo, vencidos ou vencendo nos próximos 30 dias." },
  { icon: <FileBarChart className="h-5 w-5" />, title: "Gere relatórios", body: "Em Relatórios você exporta o catálogo e o histórico em PDF ou Excel, com ranking dos produtos mais vendidos." },
  { icon: <ScanLine className="h-5 w-5" />, title: "Use o scanner", body: "A página Scanner abre a câmera e lê códigos de barras ou QR codes para localizar produtos rapidamente." },
  { icon: <Sparkles className="h-5 w-5" />, title: "Converse com a IA", body: "O Assistente IA analisa o histórico de vendas e sugere o que repor primeiro, com base em consumo e validade." },
  { icon: <ShieldCheck className="h-5 w-5" />, title: "Níveis de acesso", body: "Funcionários veem produtos e registram movimentações. Administradores também cadastram produtos, gerenciam usuários e excluem registros." },
  { icon: <Boxes className="h-5 w-5" />, title: "Backup", body: "Em Relatórios → Backup você baixa um JSON completo do banco. Restaurações são feitas pelo painel da Cloud." },
];

function TutorialPage() {
  return (
    <div className="space-y-6">
      <PageHeader title="Como usar o SmartStock" subtitle="Tudo o que você precisa saber em 8 passos" />
      <div className="grid gap-4 md:grid-cols-2">
        {STEPS.map((s, i) => (
          <Card key={i} className="border-border/60">
            <CardContent className="p-5 flex gap-4">
              <div className="shrink-0 rounded-xl bg-gradient-primary p-2.5 text-primary-foreground shadow-glow h-fit">{s.icon}</div>
              <div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground">Passo {i + 1}</div>
                <div className="font-semibold mt-0.5">{s.title}</div>
                <p className="text-sm text-muted-foreground mt-1">{s.body}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}