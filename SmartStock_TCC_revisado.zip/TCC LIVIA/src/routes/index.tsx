import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth-context";
import { Boxes } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SmartStock — Entrando" },
      { name: "description", content: "Carregando o SmartStock." },
    ],
  }),
  component: Index,
});

function Index() {
  const { session, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (loading) return;
    if (session) navigate({ to: "/dashboard" });
    else navigate({ to: "/login" });
  }, [loading, session, navigate]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background grid-bg">
      <div className="flex flex-col items-center gap-4 animate-in fade-in duration-500">
        <div className="rounded-2xl bg-gradient-primary p-4 shadow-glow">
          <Boxes className="h-10 w-10 text-primary-foreground" />
        </div>
        <h1 className="text-2xl font-semibold tracking-tight">SmartStock</h1>
        <p className="text-sm text-muted-foreground">Iniciando sua sessão…</p>
      </div>
    </div>
  );
}
