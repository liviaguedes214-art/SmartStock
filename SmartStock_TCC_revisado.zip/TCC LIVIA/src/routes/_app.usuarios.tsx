import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { useAuth } from "@/lib/auth-context";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Shield, User } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/usuarios")({
  head: () => ({ meta: [{ title: "Usuários — SmartStock" }] }),
  component: UsersPage,
});

interface UserRow {
  id: string;
  full_name: string | null;
  email: string | null;
  created_at: string;
  roles: string[];
}

function UsersPage() {
  const { isAdmin, user, loading } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();

  useEffect(() => {
    if (!loading && !isAdmin) navigate({ to: "/dashboard", replace: true });
  }, [isAdmin, loading, navigate]);

  const users = useQuery({
    queryKey: ["users"],
    queryFn: async () => {
      const [{ data: profiles }, { data: roles }] = await Promise.all([
        supabase.from("profiles").select("id, full_name, email, created_at").order("created_at", { ascending: false }),
        supabase.from("user_roles").select("user_id, role"),
      ]);
      const byUser = new Map<string, string[]>();
      (roles ?? []).forEach((r) => { const arr = byUser.get(r.user_id) ?? []; arr.push(r.role as string); byUser.set(r.user_id, arr); });
      return ((profiles ?? []) as UserRow[]).map((p) => ({ ...p, roles: byUser.get(p.id) ?? [] }));
    },
    enabled: isAdmin,
  });

  const setRole = async (userId: string, role: "admin" | "employee") => {
    const { error } = await supabase.rpc("set_user_role", {
      target_user: userId,
      new_role: role,
    });
    if (error) return toast.error("Erro", { description: error.message });
    toast.success("Papel atualizado");
    await qc.invalidateQueries({ queryKey: ["users"] });
    if (userId === user?.id) await qc.invalidateQueries();
  };

  if (!isAdmin) return null;

  return (
    <div className="space-y-6">
      <PageHeader title="Usuários" subtitle="Gerencie os níveis de acesso da equipe" />
      <Card className="border-border/60 overflow-hidden">
        <CardContent className="p-0 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Usuário</TableHead>
                <TableHead>E-mail</TableHead>
                <TableHead>Papel</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(users.data ?? []).map((u) => {
                const initials = (u.full_name || u.email || "U").split(" ").map((s) => s[0]).slice(0, 2).join("").toUpperCase();
                const role = u.roles.includes("admin") ? "admin" : "employee";
                const isSelf = u.id === user?.id;
                return (
                  <TableRow key={u.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8"><AvatarFallback className="bg-primary/20 text-primary text-xs">{initials}</AvatarFallback></Avatar>
                        <div className="font-medium">{u.full_name || "—"} {isSelf && <Badge variant="outline" className="ml-2 text-[10px]">Você</Badge>}</div>
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">{u.email}</TableCell>
                    <TableCell>
                      <Badge variant={role === "admin" ? "default" : "secondary"} className="gap-1">
                        {role === "admin" ? <Shield className="h-3 w-3" /> : <User className="h-3 w-3" />}
                        {role === "admin" ? "Administrador" : "Funcionário"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        {role !== "admin" && <Button size="sm" variant="outline" onClick={() => setRole(u.id, "admin")} disabled={isSelf}>Tornar admin</Button>}
                        {role !== "employee" && <Button size="sm" variant="outline" onClick={() => setRole(u.id, "employee")} disabled={isSelf}>Tornar funcionário</Button>}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      <p className="text-xs text-muted-foreground">
        Para adicionar novos usuários, peça que se cadastrem na tela de login. Por padrão entram como funcionário.
      </p>
    </div>
  );
}