import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Boxes, AlertTriangle, CalendarClock, TrendingUp, DollarSign, ArrowRight,
  Activity,
} from "lucide-react";
import {
  Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
  PieChart, Pie, Cell, Legend,
} from "recharts";
import { CATEGORY_LABEL, MOVEMENT_LABEL, type CategoryValue } from "@/lib/constants";
import { formatCurrency, formatDateTime, daysUntil } from "@/lib/format";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_app/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — SmartStock" }] }),
  component: Dashboard,
});

const CHART_COLORS = ["hsl(195 80% 60%)", "hsl(155 60% 55%)", "hsl(75 70% 60%)", "hsl(230 70% 65%)", "hsl(320 60% 65%)", "hsl(20 70% 60%)"];

function Dashboard() {
  const products = useQuery({
    queryKey: ["dashboard-products"],
    queryFn: async () => {
      const { data, error } = await supabase.from("products").select("*").limit(1000);
      if (error) throw error;
      return data ?? [];
    },
  });

  const movements = useQuery({
    queryKey: ["dashboard-movements"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("movements")
        .select("*, products(name, category)")
        .order("created_at", { ascending: false })
        .limit(1000);
      if (error) throw error;
      return data ?? [];
    },
  });

  const prods = products.data ?? [];
  const moves = movements.data ?? [];

  const totalProducts = prods.length;
  const lowStock = prods.filter((p) => p.quantity <= p.min_quantity).length;
  const expiring = prods.filter((p) => {
    const d = daysUntil(p.expiry_date);
    return d !== null && d <= 30 && d >= 0;
  }).length;

  const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);
  const monthMoves = moves.filter((m) => new Date(m.created_at) >= monthStart);
  const monthSales = monthMoves.filter((m) => m.type === "saida");
  const salesTotal = monthSales.reduce((s, m) => s + Number(m.total ?? 0), 0);
  const costTotal = monthSales.reduce((s, m) => {
    const cost = (m.products as { name?: string } | null) ? 0 : 0;
    return s + cost;
  }, 0);
  // Estimated profit = sales total - estimated cost (price - cost per unit). We approximate with product cost lookup.
  const productCostMap = new Map(prods.map((p) => [p.id, Number(p.cost_price ?? 0)]));
  const estimatedProfit = monthSales.reduce((s, m) => {
    const unitCost = productCostMap.get(m.product_id) ?? 0;
    return s + (Number(m.unit_price ?? 0) - unitCost) * m.quantity;
  }, 0);

  // Last 14 days movement chart
  const dayBuckets = Array.from({ length: 14 }).map((_, i) => {
    const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - (13 - i));
    return { date: d, label: d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" }), entrada: 0, saida: 0, perda: 0 };
  });
  for (const m of moves) {
    const md = new Date(m.created_at); md.setHours(0, 0, 0, 0);
    const bucket = dayBuckets.find((b) => b.date.getTime() === md.getTime());
    if (bucket) {
      if (m.type === "entrada") bucket.entrada += m.quantity;
      else if (m.type === "saida") bucket.saida += m.quantity;
      else if (m.type === "perda") bucket.perda += m.quantity;
    }
  }

  // Category distribution
  const categoryCounts = new Map<CategoryValue, number>();
  prods.forEach((p) => categoryCounts.set(p.category, (categoryCounts.get(p.category) ?? 0) + p.quantity));
  const categoryData = Array.from(categoryCounts.entries()).map(([cat, qty]) => ({
    name: CATEGORY_LABEL[cat] ?? cat, value: qty,
  }));

  const recent = moves.slice(0, 6);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Dashboard"
        subtitle="Visão geral em tempo real do seu estoque"
        actions={
          <Link to="/produtos"><Button variant="outline">Ver produtos <ArrowRight className="h-4 w-4" /></Button></Link>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard icon={<Boxes className="h-4 w-4" />} label="Produtos cadastrados" value={totalProducts.toString()} hint="Total no catálogo" />
        <KpiCard icon={<AlertTriangle className="h-4 w-4" />} label="Estoque baixo" value={lowStock.toString()} hint="Abaixo do mínimo" tone="warning" />
        <KpiCard icon={<CalendarClock className="h-4 w-4" />} label="Vencendo em 30 dias" value={expiring.toString()} hint="Validade próxima" tone="warning" />
        <KpiCard icon={<DollarSign className="h-4 w-4" />} label="Vendas do mês" value={formatCurrency(salesTotal)} hint={`Lucro estimado ${formatCurrency(estimatedProfit)}`} tone="success" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2 border-border/60">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base">Movimentações — últimos 14 dias</CardTitle>
              <p className="text-xs text-muted-foreground mt-1">Entradas, saídas e perdas por dia</p>
            </div>
            <Badge variant="outline" className="border-primary/30 text-primary"><Activity className="h-3 w-3" /> ao vivo</Badge>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={dayBuckets}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(0 0% 100% / 0.05)" />
                <XAxis dataKey="label" stroke="hsl(0 0% 100% / 0.4)" fontSize={11} />
                <YAxis stroke="hsl(0 0% 100% / 0.4)" fontSize={11} />
                <Tooltip contentStyle={{ background: "hsl(220 25% 14%)", border: "1px solid hsl(220 20% 25%)", borderRadius: 8 }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="entrada" name="Entrada" fill={CHART_COLORS[1]} radius={[4, 4, 0, 0]} />
                <Bar dataKey="saida" name="Saída" fill={CHART_COLORS[0]} radius={[4, 4, 0, 0]} />
                <Bar dataKey="perda" name="Perda" fill={CHART_COLORS[5]} radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="text-base">Estoque por categoria</CardTitle>
            <p className="text-xs text-muted-foreground">Quantidade total em unidades</p>
          </CardHeader>
          <CardContent>
            {categoryData.length === 0 ? (
              <p className="text-sm text-muted-foreground py-8 text-center">Sem dados ainda.</p>
            ) : (
              <ResponsiveContainer width="100%" height={280}>
                <PieChart>
                  <Pie data={categoryData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={2}>
                    {categoryData.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: "hsl(220 25% 14%)", border: "1px solid hsl(220 20% 25%)", borderRadius: 8 }} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="border-border/60">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><TrendingUp className="h-4 w-4 text-primary" /> Movimentações recentes</CardTitle>
        </CardHeader>
        <CardContent>
          {recent.length === 0 ? (
            <p className="text-sm text-muted-foreground py-6 text-center">Nenhuma movimentação registrada ainda.</p>
          ) : (
            <div className="divide-y divide-border/60">
              {recent.map((m) => (
                <div key={m.id} className="py-3 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3 min-w-0">
                    <Badge variant={m.type === "entrada" ? "default" : m.type === "saida" ? "secondary" : "destructive"} className="capitalize">
                      {MOVEMENT_LABEL[m.type as keyof typeof MOVEMENT_LABEL]}
                    </Badge>
                    <div className="min-w-0">
                      <div className="text-sm font-medium truncate">{(m.products as { name?: string } | null)?.name ?? "Produto"}</div>
                      <div className="text-xs text-muted-foreground">{formatDateTime(m.created_at)}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium">{m.quantity} un.</div>
                    <div className="text-xs text-muted-foreground">{formatCurrency(m.total)}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function KpiCard({ icon, label, value, hint, tone }: { icon: React.ReactNode; label: string; value: string; hint?: string; tone?: "warning" | "success" }) {
  const toneCls = tone === "warning" ? "text-warning" : tone === "success" ? "text-success" : "text-primary";
  return (
    <Card className="border-border/60 relative overflow-hidden shadow-card">
      <div className={`absolute -top-8 -right-8 h-24 w-24 rounded-full blur-2xl opacity-30 ${tone === "warning" ? "bg-warning" : tone === "success" ? "bg-success" : "bg-primary"}`} />
      <CardContent className="p-5 relative">
        <div className="flex items-center justify-between">
          <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
          <span className={`rounded-md bg-card border border-border p-1.5 ${toneCls}`}>{icon}</span>
        </div>
        <div className="mt-3 text-2xl font-semibold tracking-tight">{value}</div>
        {hint && <div className="mt-1 text-xs text-muted-foreground">{hint}</div>}
      </CardContent>
    </Card>
  );
}