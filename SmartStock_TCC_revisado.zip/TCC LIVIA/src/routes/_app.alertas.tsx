import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, CalendarX, PackageX } from "lucide-react";
import { formatDate, daysUntil } from "@/lib/format";
import { CATEGORY_LABEL, type CategoryValue } from "@/lib/constants";

export const Route = createFileRoute("/_app/alertas")({
  head: () => ({ meta: [{ title: "Alertas — SmartStock" }] }),
  component: AlertsPage,
});

interface ProductLite {
  id: string;
  name: string;
  code: string;
  category: string;
  quantity: number;
  min_quantity: number;
  expiry_date: string | null;
}

function AlertsPage() {
  const products = useQuery({
    queryKey: ["alerts-products"],
    queryFn: async () => {
      const { data, error } = await supabase.from("products").select("id, name, code, category, quantity, min_quantity, expiry_date").limit(1000);
      if (error) throw error;
      return (data ?? []) as ProductLite[];
    },
  });

  const prods = products.data ?? [];
  const low = prods.filter((p) => p.quantity <= p.min_quantity && p.quantity > 0);
  const empty = prods.filter((p) => p.quantity === 0);
  const expired = prods.filter((p) => { const d = daysUntil(p.expiry_date); return d !== null && d < 0; });
  const expiring = prods.filter((p) => { const d = daysUntil(p.expiry_date); return d !== null && d >= 0 && d <= 30; });

  return (
    <div className="space-y-6">
      <PageHeader title="Alertas" subtitle="Produtos críticos exigindo atenção imediata" />
      <AlertSection title="Estoque zerado" items={empty} icon={<PackageX className="h-4 w-4" />} tone="destructive" renderHint={() => "Sem estoque — repor urgente"} />
      <AlertSection title="Estoque baixo" items={low} icon={<AlertTriangle className="h-4 w-4" />} tone="warning" renderHint={(p) => `${p.quantity} un. (mínimo ${p.min_quantity})`} />
      <AlertSection title="Vencidos" items={expired} icon={<CalendarX className="h-4 w-4" />} tone="destructive" renderHint={(p) => `Venceu em ${formatDate(p.expiry_date)}`} />
      <AlertSection title="Vencendo em até 30 dias" items={expiring} icon={<CalendarX className="h-4 w-4" />} tone="warning" renderHint={(p) => `Vence em ${daysUntil(p.expiry_date)} dias`} />
    </div>
  );
}

function AlertSection({ title, items, icon, tone, renderHint }: {
  title: string; items: ProductLite[]; icon: React.ReactNode; tone: "warning" | "destructive"; renderHint: (p: ProductLite) => string;
}) {
  const toneCls = tone === "destructive" ? "border-destructive/40 text-destructive" : "border-warning/40 text-warning";
  return (
    <Card className="border-border/60">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-base flex items-center gap-2">
          <span className={`rounded-md border p-1.5 ${toneCls}`}>{icon}</span>
          {title}
        </CardTitle>
        <Badge variant="outline">{items.length}</Badge>
      </CardHeader>
      <CardContent>
        {items.length === 0 ? (
          <p className="text-sm text-muted-foreground py-4">Nada por aqui — tudo certo!</p>
        ) : (
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((p) => (
              <div key={p.id} className={`rounded-lg border p-3 bg-card ${tone === "destructive" ? "border-destructive/30" : "border-warning/30"}`}>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="font-medium truncate">{p.name}</div>
                    <div className="text-xs text-muted-foreground font-mono">{p.code}</div>
                  </div>
                  <Badge variant="outline" className="text-[10px]">{CATEGORY_LABEL[p.category as CategoryValue]}</Badge>
                </div>
                <div className={`mt-2 text-xs ${tone === "destructive" ? "text-destructive" : "text-warning"}`}>{renderHint(p)}</div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}