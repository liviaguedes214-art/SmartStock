import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Boxes, Loader2, ShieldCheck, Sparkles, TrendingUp } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Entrar — SmartStock" },
      { name: "description", content: "Acesse o painel SmartStock com sua conta de funcionário ou administrador." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const { session, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && session) navigate({ to: "/dashboard", replace: true });
  }, [session, loading, navigate]);

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-background">
      <aside className="hidden lg:flex relative overflow-hidden flex-col justify-between p-12 bg-gradient-surface border-r border-border">
        <div className="absolute inset-0 grid-bg opacity-40" />
        <div className="absolute -top-24 -right-24 h-72 w-72 rounded-full bg-primary/20 blur-3xl" />
        <div className="relative">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-gradient-primary p-2 shadow-glow">
              <Boxes className="h-6 w-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-semibold tracking-tight">SmartStock</span>
          </div>
        </div>
        <div className="relative space-y-6">
          <h2 className="text-4xl font-semibold leading-tight tracking-tight">
            Controle <span className="text-gradient">inteligente</span><br />do seu estoque.
          </h2>
          <p className="text-muted-foreground max-w-md">
            Dashboard em tempo real, alertas automáticos, scanner de código de barras e IA para sugerir reposições.
          </p>
          <ul className="space-y-3 text-sm">
            <Feature icon={<TrendingUp className="h-4 w-4" />} text="Dashboards interativos e relatórios exportáveis" />
            <Feature icon={<ShieldCheck className="h-4 w-4" />} text="Níveis de acesso para funcionários e administradores" />
            <Feature icon={<Sparkles className="h-4 w-4" />} text="IA sugere reposição automática baseada no histórico" />
          </ul>
        </div>
        <div className="relative text-xs text-muted-foreground">© {new Date().getFullYear()} SmartStock</div>
      </aside>

      <main className="flex items-center justify-center p-6 sm:p-12">
        <Card className="w-full max-w-md border-border/60 shadow-card">
          <CardHeader>
            <CardTitle className="text-2xl">Bem-vindo</CardTitle>
            <CardDescription>Entre na sua conta ou cadastre-se para começar.</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="signin">
              <TabsList className="grid grid-cols-2 w-full">
                <TabsTrigger value="signin">Entrar</TabsTrigger>
                <TabsTrigger value="signup">Cadastrar</TabsTrigger>
              </TabsList>
              <TabsContent value="signin"><SignInForm /></TabsContent>
              <TabsContent value="signup"><SignUpForm /></TabsContent>
            </Tabs>
            <p className="mt-6 text-xs text-muted-foreground text-center">
              O primeiro usuário cadastrado vira <span className="font-medium text-foreground">Administrador</span> automaticamente.
            </p>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}

function Feature({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <li className="flex items-center gap-3">
      <span className="rounded-md bg-primary/10 text-primary p-1.5">{icon}</span>
      <span className="text-foreground/80">{text}</span>
    </li>
  );
}

function SignInForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setSubmitting(false);
    if (error) {
      toast.error("Falha ao entrar", { description: error.message });
      return;
    }
    toast.success("Bem-vindo!");
    navigate({ to: "/dashboard", replace: true });
  };

  return (
    <form onSubmit={submit} className="space-y-4 mt-4">
      <div className="space-y-2">
        <Label htmlFor="si-email">E-mail</Label>
        <Input id="si-email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@empresa.com" />
      </div>
      <div className="space-y-2">
        <Label htmlFor="si-pass">Senha</Label>
        <Input id="si-pass" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
      </div>
      <Button type="submit" className="w-full" disabled={submitting}>
        {submitting && <Loader2 className="h-4 w-4 animate-spin" />} Entrar
      </Button>
    </form>
  );
}

function SignUpForm() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 6) {
      toast.error("Senha muito curta", { description: "Use pelo menos 6 caracteres." });
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/`,
        data: { full_name: name },
      },
    });
    setSubmitting(false);
    if (error) {
      toast.error("Falha ao cadastrar", { description: error.message });
      return;
    }
    toast.success("Conta criada!", { description: "Você já pode entrar." });
    navigate({ to: "/dashboard", replace: true });
  };

  return (
    <form onSubmit={submit} className="space-y-4 mt-4">
      <div className="space-y-2">
        <Label htmlFor="su-name">Nome completo</Label>
        <Input id="su-name" required value={name} onChange={(e) => setName(e.target.value)} placeholder="Maria Silva" />
      </div>
      <div className="space-y-2">
        <Label htmlFor="su-email">E-mail</Label>
        <Input id="su-email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@empresa.com" />
      </div>
      <div className="space-y-2">
        <Label htmlFor="su-pass">Senha</Label>
        <Input id="su-pass" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Mínimo 6 caracteres" />
      </div>
      <Button type="submit" className="w-full" disabled={submitting}>
        {submitting && <Loader2 className="h-4 w-4 animate-spin" />} Criar conta
      </Button>
    </form>
  );
}