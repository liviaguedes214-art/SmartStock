import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, Pencil, Trash2, ArrowLeftRight } from "lucide-react";
import { CATEGORIES, CATEGORY_LABEL, type CategoryValue } from "@/lib/constants";
import { ProductFormDialog, type ProductRow } from "@/components/product-form-dialog";
import { MovementDialog } from "@/components/movement-dialog";
import { formatCurrency, formatDate, daysUntil } from "@/lib/format";
import { useAuth } from "@/lib/auth-context";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/produtos")({
  head: () => ({ meta: [{ title: "Produtos — SmartStock" }] }),
  component: ProductsPage,
});

function ProductsPage() {
  const qc = useQueryClient();
  const { isAdmin } = useAuth();
  const [search, setSearch] = useState("");
  const [cat, setCat] = useState<string>("all");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<ProductRow | undefined>(undefined);
  const [moveProductId, setMoveProductId] = useState<string | null>(null);

  const products = useQuery({
    queryKey: ["products"],
    queryFn: async () => {
      const { data, error } = await supabase.from("products").select("*").order("created_at", { ascending: false }).limit(1000);
      if (error) throw error;
      return data ?? [];
    },
  });

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return (products.data ?? []).filter((p) => {
      const matchTerm = !term || p.name.toLowerCase().includes(term) || p.code.toLowerCase().includes(term);
      const matchCat = cat === "all" || p.category === cat;
      return matchTerm && matchCat;
    });
  }, [products.data, search, cat]);

  const remove = async (id: string) => {
    if (!confirm("Excluir este produto e todas as movimentações associadas?")) return;
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) return toast.error("Erro ao excluir", { description: error.message });
    toast.success("Produto excluído");
    qc.invalidateQueries({ queryKey: ["products"] });
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Produtos"
        subtitle="Catálogo completo com busca por nome, código ou categoria"
        actions={
          isAdmin && (
            <Button onClick={() => { setEditing(undefined); setFormOpen(true); }}>
              <Plus className="h-4 w-4" /> Novo produto
            </Button>
          )
        }
      />

      <Card className="border-border/60">
        <CardContent className="p-4 flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input className="pl-9" placeholder="Buscar por nome ou código…" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <Select value={cat} onValueChange={setCat}>
            <SelectTrigger className="sm:w-56"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as categorias</SelectItem>
              {CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Card className="border-border/60 overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Produto</TableHead>
                <TableHead>Categoria</TableHead>
                <TableHead className="text-right">Estoque</TableHead>
                <TableHead className="text-right">Preço</TableHead>
                <TableHead>Validade</TableHead>
                <TableHead>Localização</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">Nenhum produto encontrado.</TableCell></TableRow>
              ) : filtered.map((p) => {
                const low = p.quantity <= p.min_quantity;
                const days = daysUntil(p.expiry_date);
                const exp = days !== null && days <= 30;
                return (
                  <TableRow key={p.id}>
                    <TableCell>
                      <div className="font-medium">{p.name}</div>
                      <div className="text-xs text-muted-foreground font-mono">{p.code}</div>
                    </TableCell>
                    <TableCell><Badge variant="outline">{CATEGORY_LABEL[p.category as CategoryValue]}</Badge></TableCell>
                    <TableCell className="text-right">
                      <span className={`font-medium ${low ? "text-warning" : ""}`}>{p.quantity}</span>
                      <span className="text-xs text-muted-foreground"> / min {p.min_quantity}</span>
                    </TableCell>
                    <TableCell className="text-right">{formatCurrency(p.price)}</TableCell>
                    <TableCell>
                      <span className={exp ? (days! < 0 ? "text-destructive" : "text-warning") : ""}>{formatDate(p.expiry_date)}</span>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">{p.location ?? "—"}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button size="icon" variant="ghost" title="Registrar movimentação" onClick={() => setMoveProductId(p.id)}>
                          <ArrowLeftRight className="h-4 w-4" />
                        </Button>
                        {isAdmin && (
                          <>
                            <Button size="icon" variant="ghost" title="Editar" onClick={() => { setEditing(p as ProductRow); setFormOpen(true); }}>
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button size="icon" variant="ghost" title="Excluir" onClick={() => remove(p.id)}>
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </Card>

      <ProductFormDialog open={formOpen} onOpenChange={setFormOpen} initial={editing} onSaved={() => qc.invalidateQueries({ queryKey: ["products"] })} />
      <MovementDialog
        productId={moveProductId}
        open={moveProductId !== null}
        onOpenChange={(v: boolean) => !v && setMoveProductId(null)}
        onSaved={() => qc.invalidateQueries()}
      />
    </div>
  );
}