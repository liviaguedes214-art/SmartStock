import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileDown, FileSpreadsheet, FileText, Database, TrendingUp } from "lucide-react";
import { formatCurrency, formatDate, formatDateTime } from "@/lib/format";
import { CATEGORY_LABEL, MOVEMENT_LABEL, type CategoryValue } from "@/lib/constants";
import { toast } from "sonner";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export const Route = createFileRoute("/_app/relatorios")({
  head: () => ({ meta: [{ title: "Relatórios — SmartStock" }] }),
  component: ReportsPage,
});

function ReportsPage() {
  const products = useQuery({
    queryKey: ["report-products"],
    queryFn: async () => {
      const { data, error } = await supabase.from("products").select("*").limit(2000);
      if (error) throw error;
      return data ?? [];
    },
  });
  const movements = useQuery({
    queryKey: ["report-movements"],
    queryFn: async () => {
      const { data, error } = await supabase.from("movements").select("*, products(name, code, cost_price)").order("created_at", { ascending: false }).limit(5000);
      if (error) throw error;
      return data ?? [];
    },
  });

  const prods = products.data ?? [];
  const moves = movements.data ?? [];

  // Ranking top sales (this month)
  const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);
  const sales = moves.filter((m) => m.type === "saida" && new Date(m.created_at) >= monthStart);
  const rankMap = new Map<string, { name: string; qty: number; total: number }>();
  for (const s of sales) {
    const p = s.products as { name?: string } | null;
    const k = s.product_id;
    const e = rankMap.get(k) ?? { name: p?.name ?? "—", qty: 0, total: 0 };
    e.qty += s.quantity; e.total += Number(s.total ?? 0);
    rankMap.set(k, e);
  }
  const ranking = Array.from(rankMap.values()).sort((a, b) => b.qty - a.qty).slice(0, 10);

  const totalSales = sales.reduce((s, m) => s + Number(m.total ?? 0), 0);
  const totalCost = sales.reduce((s, m) => {
    const cost = Number((m.products as { cost_price?: number } | null)?.cost_price ?? 0);
    return s + cost * m.quantity;
  }, 0);
  const profit = totalSales - totalCost;

  const exportPdfProducts = async () => {
    const { default: jsPDF } = await import("jspdf");
    const autoTable = (await import("jspdf-autotable")).default;
    const doc = new jsPDF();
    doc.setFontSize(16); doc.text("SmartStock — Catálogo de produtos", 14, 16);
    doc.setFontSize(10); doc.setTextColor(120); doc.text(formatDateTime(new Date()), 14, 22);
    autoTable(doc, {
      startY: 28,
      head: [["Código", "Nome", "Categoria", "Estoque", "Mín.", "Preço", "Validade"]],
      body: prods.map((p) => [p.code, p.name, CATEGORY_LABEL[p.category as CategoryValue], p.quantity, p.min_quantity, formatCurrency(p.price), formatDate(p.expiry_date)]),
      styles: { fontSize: 9 },
      headStyles: { fillColor: [45, 55, 72] },
    });
    doc.save(`smartstock-produtos-${Date.now()}.pdf`);
    toast.success("PDF gerado");
  };

  const exportPdfMovements = async () => {
    const { default: jsPDF } = await import("jspdf");
    const autoTable = (await import("jspdf-autotable")).default;
    const doc = new jsPDF();
    doc.setFontSize(16); doc.text("SmartStock — Movimentações", 14, 16);
    doc.setFontSize(10); doc.setTextColor(120); doc.text(formatDateTime(new Date()), 14, 22);
    autoTable(doc, {
      startY: 28,
      head: [["Data", "Produto", "Tipo", "Qtd", "Unitário", "Total"]],
      body: moves.map((m) => {
        const p = m.products as { name?: string } | null;
        return [formatDateTime(m.created_at), p?.name ?? "—", MOVEMENT_LABEL[m.type as keyof typeof MOVEMENT_LABEL], m.quantity, formatCurrency(m.unit_price), formatCurrency(m.total)];
      }),
      styles: { fontSize: 9 },
      headStyles: { fillColor: [45, 55, 72] },
    });
    doc.save(`smartstock-movimentacoes-${Date.now()}.pdf`);
    toast.success("PDF gerado");
  };

  const exportExcel = async () => {
    const XLSX = await import("xlsx");
    const wb = XLSX.utils.book_new();
    const wsProds = XLSX.utils.json_to_sheet(prods.map((p) => ({
      Codigo: p.code, Nome: p.name, Categoria: CATEGORY_LABEL[p.category as CategoryValue],
      Estoque: p.quantity, Minimo: p.min_quantity, Preco: Number(p.price), Custo: Number(p.cost_price),
      Fornecedor: p.supplier ?? "", Validade: p.expiry_date ?? "", Localizacao: p.location ?? "",
    })));
    const wsMoves = XLSX.utils.json_to_sheet(moves.map((m) => {
      const p = m.products as { name?: string; code?: string } | null;
      return {
        Data: m.created_at, Produto: p?.name ?? "", Codigo: p?.code ?? "",
        Tipo: MOVEMENT_LABEL[m.type as keyof typeof MOVEMENT_LABEL],
        Quantidade: m.quantity, Unitario: Number(m.unit_price), Total: Number(m.total), Observacao: m.reason ?? "",
      };
    }));
    XLSX.utils.book_append_sheet(wb, wsProds, "Produtos");
    XLSX.utils.book_append_sheet(wb, wsMoves, "Movimentações");
    XLSX.writeFile(wb, `smartstock-${Date.now()}.xlsx`);
    toast.success("Excel gerado");
  };

  const backup = () => {
    const blob = new Blob([JSON.stringify({ products: prods, movements: moves, exported_at: new Date().toISOString() }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `smartstock-backup-${Date.now()}.json`; a.click();
    URL.revokeObjectURL(url);
    toast.success("Backup baixado");
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Relatórios" subtitle="Exporte dados, gere relatórios e baixe backups" />

      <div className="grid gap-4 sm:grid-cols-3">
        <KpiSmall label="Vendas do mês" value={formatCurrency(totalSales)} />
        <KpiSmall label="Custo estimado" value={formatCurrency(totalCost)} />
        <KpiSmall label="Lucro estimado" value={formatCurrency(profit)} tone="success" />
      </div>

      <Card className="border-border/60">
        <CardHeader>
          <CardTitle className="text-base">Exportações</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button onClick={exportPdfProducts}><FileText className="h-4 w-4" /> Produtos (PDF)</Button>
          <Button onClick={exportPdfMovements}><FileText className="h-4 w-4" /> Movimentações (PDF)</Button>
          <Button variant="outline" onClick={exportExcel}><FileSpreadsheet className="h-4 w-4" /> Excel completo</Button>
          <Button variant="outline" onClick={backup}><Database className="h-4 w-4" /> Backup JSON</Button>
        </CardContent>
      </Card>

      <Card className="border-border/60">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><TrendingUp className="h-4 w-4 text-primary" /> Ranking — Top 10 mais vendidos (mês)</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">#</TableHead>
                <TableHead>Produto</TableHead>
                <TableHead className="text-right">Quantidade</TableHead>
                <TableHead className="text-right">Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {ranking.length === 0 ? (
                <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">Sem vendas este mês.</TableCell></TableRow>
              ) : ranking.map((r, i) => (
                <TableRow key={i}>
                  <TableCell className="font-mono text-muted-foreground">{i + 1}</TableCell>
                  <TableCell className="font-medium">{r.name}</TableCell>
                  <TableCell className="text-right">{r.qty}</TableCell>
                  <TableCell className="text-right font-medium">{formatCurrency(r.total)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

function KpiSmall({ label, value, tone }: { label: string; value: string; tone?: "success" }) {
  return (
    <Card className="border-border/60">
      <CardContent className="p-4">
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className={`mt-2 text-xl font-semibold ${tone === "success" ? "text-success" : ""}`}>{value}</div>
      </CardContent>
    </Card>
  );
}