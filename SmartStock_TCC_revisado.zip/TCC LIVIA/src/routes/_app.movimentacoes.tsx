import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { MOVEMENT_LABEL } from "@/lib/constants";

export const Route = createFileRoute("/_app/movimentacoes")({
  head: () => ({ meta: [{ title: "Movimentações — SmartStock" }] }),
  component: MovementsPage,
});

function MovementsPage() {
  const [search, setSearch] = useState("");
  const [type, setType] = useState("all");

  const data = useQuery({
    queryKey: ["movements-all"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("movements")
        .select("*, products(name, code)")
        .order("created_at", { ascending: false })
        .limit(1000);
      if (error) throw error;
      return data ?? [];
    },
  });

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return (data.data ?? []).filter((m) => {
      const p = m.products as { name?: string; code?: string } | null;
      const matchTerm = !term || ((p?.name?.toLowerCase().includes(term) ?? false) || (p?.code?.toLowerCase().includes(term) ?? false));
      const matchType = type === "all" || m.type === type;
      return matchTerm && matchType;
    });
  }, [data.data, search, type]);

  return (
    <div className="space-y-6">
      <PageHeader title="Movimentações" subtitle="Histórico completo de entradas, saídas e perdas" />
      <Card className="border-border/60">
        <CardContent className="p-4 flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input className="pl-9" placeholder="Buscar por produto ou código…" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <Select value={type} onValueChange={setType}>
            <SelectTrigger className="sm:w-48"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os tipos</SelectItem>
              <SelectItem value="entrada">Entradas</SelectItem>
              <SelectItem value="saida">Saídas</SelectItem>
              <SelectItem value="perda">Perdas</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Card className="border-border/60 overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data</TableHead>
                <TableHead>Produto</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead className="text-right">Qtd</TableHead>
                <TableHead className="text-right">Unitário</TableHead>
                <TableHead className="text-right">Total</TableHead>
                <TableHead>Observação</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">Nenhuma movimentação.</TableCell></TableRow>
              ) : filtered.map((m) => {
                const p = m.products as { name?: string; code?: string } | null;
                return (
                  <TableRow key={m.id}>
                    <TableCell className="text-sm">{formatDateTime(m.created_at)}</TableCell>
                    <TableCell>
                      <div className="font-medium">{p?.name ?? "—"}</div>
                      <div className="text-xs text-muted-foreground font-mono">{p?.code}</div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={m.type === "entrada" ? "default" : m.type === "saida" ? "secondary" : "destructive"}>
                        {MOVEMENT_LABEL[m.type as keyof typeof MOVEMENT_LABEL]}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">{m.quantity}</TableCell>
                    <TableCell className="text-right">{formatCurrency(m.unit_price)}</TableCell>
                    <TableCell className="text-right font-medium">{formatCurrency(m.total)}</TableCell>
                    <TableCell className="text-sm text-muted-foreground max-w-[200px] truncate">{m.reason ?? "—"}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}