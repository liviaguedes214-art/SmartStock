import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { useRef, useState } from "react";
import { suggestReposition, recognizeProductImage } from "@/lib/ai.functions";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Loader2, Camera, Image as ImageIcon } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/ia")({
  head: () => ({ meta: [{ title: "Assistente IA — SmartStock" }] }),
  component: AIPage,
});

function AIPage() {
  const suggestFn = useServerFn(suggestReposition);
  const recogFn = useServerFn(recognizeProductImage);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [imgPreview, setImgPreview] = useState<string | null>(null);
  const [recogResult, setRecogResult] = useState<{ nome?: string; categoria?: string; descricao?: string } | null>(null);

  const suggest = useMutation({
    mutationFn: () => suggestFn(),
    onError: (e) => toast.error("Erro ao consultar IA", { description: String(e instanceof Error ? e.message : e) }),
  });

  const recog = useMutation({
    mutationFn: (imageDataUrl: string) => recogFn({ data: { imageDataUrl } }),
    onSuccess: (data) => setRecogResult(data),
    onError: (e) => toast.error("Erro ao reconhecer", { description: String(e instanceof Error ? e.message : e) }),
  });

  const onFile = async (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const url = reader.result as string;
      setImgPreview(url);
      setRecogResult(null);
      recog.mutate(url);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Assistente IA"
        subtitle="Análise inteligente de reposição e reconhecimento de produtos"
        actions={<Badge variant="outline" className="border-primary/30 text-primary"><Sparkles className="h-3 w-3" /> Powered by Lovable AI</Badge>}
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2"><Sparkles className="h-4 w-4 text-primary" /> Sugestão de reposição automática</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">A IA analisa estoque atual, mínimos, validade e velocidade de saída para sugerir prioridades de compra.</p>
            <Button onClick={() => suggest.mutate()} disabled={suggest.isPending}>
              {suggest.isPending ? <><Loader2 className="h-4 w-4 animate-spin" /> Analisando…</> : <><Sparkles className="h-4 w-4" /> Gerar sugestões</>}
            </Button>
            {suggest.data && (
              <div className="rounded-lg border border-border/60 bg-card/50 p-4 prose prose-invert prose-sm max-w-none whitespace-pre-wrap text-sm">
                {suggest.data.answer}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2"><Camera className="h-4 w-4 text-primary" /> Reconhecimento por foto</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">Envie a foto do produto e a IA identifica nome, categoria e descrição sugeridos.</p>
            <input ref={fileInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); }} />
            <div className="flex gap-2">
              <Button onClick={() => fileInputRef.current?.click()}><ImageIcon className="h-4 w-4" /> Escolher imagem</Button>
              {imgPreview && <Button variant="outline" onClick={() => { setImgPreview(null); setRecogResult(null); }}>Limpar</Button>}
            </div>
            {imgPreview && (
              <img src={imgPreview} alt="Pré-visualização" className="max-h-56 rounded-lg border border-border/60 mx-auto" />
            )}
            {recog.isPending && <p className="text-sm text-muted-foreground flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Analisando imagem…</p>}
            {recogResult && (
              <div className="rounded-lg border border-primary/40 bg-card/50 p-4 space-y-2 text-sm">
                <div><span className="text-muted-foreground">Nome:</span> <span className="font-medium">{recogResult.nome ?? "—"}</span></div>
                <div><span className="text-muted-foreground">Categoria:</span> <Badge variant="outline" className="ml-1">{recogResult.categoria ?? "—"}</Badge></div>
                <div className="text-muted-foreground">{recogResult.descricao}</div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}