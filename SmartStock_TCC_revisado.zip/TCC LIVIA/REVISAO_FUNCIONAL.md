# Revisão funcional — SmartStock

## Correções aplicadas nesta cópia

1. Movimentações: validação de quantidade inteira e positiva, preço válido e saldo disponível antes de registrar saídas/perdas.
2. Banco de dados: nova migration valida o saldo com bloqueio da linha, evitando que duas saídas simultâneas ultrapassem o estoque.
3. Permissões: a migration devolve a permissão de execução da função `has_role`, necessária para avaliar as políticas RLS, e cria a função `set_user_role` para alterar papéis em uma única transação.
4. Usuários: a tela passa a usar a função transacional `set_user_role`.
5. Atualização de telas: após uma movimentação, as consultas do React Query são invalidadas para atualizar dashboard, histórico, alertas, relatórios e produtos.
6. Tipagem: removidos dois usos de `any` no dashboard e no scanner.
7. Segurança do pacote: o `.env` original não foi incluído nesta cópia. Use `.env.example` como modelo e preencha as variáveis no seu ambiente.

## Verificações executadas

- TypeScript (`tsc --noEmit`): passou sem erros.
- ESLint sem a regra de formatação Prettier: ainda aponta `any` no arquivo gerado `src/routeTree.gen.ts`; há também avisos de Fast Refresh em componentes da interface.
- Build Vite: não foi possível concluir neste ambiente porque o pacote opcional nativo `@rollup/rollup-linux-x64-gnu` não está presente na pasta `node_modules` extraída do ZIP.
- Não foi possível testar login, banco remoto, RLS ou fluxos reais sem conectar ao projeto Supabase.

## Pontos que ainda precisam de teste/decisão

- Testar com duas contas: administrador e funcionário, confirmando o que cada uma pode fazer.
- Testar entradas, saídas, perdas, estoque zerado e tentativas de saída acima do saldo.
- O cadastro/edição de produto altera a quantidade diretamente, sem criar movimentação de ajuste. Definir se isso é desejado ou se todo ajuste deve entrar no histórico.
- Os relatórios calculam custo/lucro usando o custo atual do cadastro do produto. Se o custo mudar, valores históricos podem mudar; o ideal é guardar o custo unitário no momento de cada movimentação.
- Algumas telas limitam a consulta a 1.000, 2.000 ou 5.000 registros. Para estoques maiores, será necessário implementar paginação.
- A tela de cadastro informa que a conta foi criada e que já pode entrar; se a confirmação de e-mail estiver ativada no Supabase, a mensagem/fluxo deve orientar a pessoa a confirmar o e-mail antes do login.

## Importante

A nova migration SQL precisa ser aplicada no Supabase antes de testar as correções de permissões e estoque. Não compartilhe o `.env`; se as chaves do arquivo original forem reais e tiverem sido expostas, gere novas chaves/segredos no painel do serviço, especialmente a chave `service_role`.
