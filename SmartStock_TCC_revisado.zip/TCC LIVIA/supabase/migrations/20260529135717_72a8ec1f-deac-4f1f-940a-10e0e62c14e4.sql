
-- Tighten product policies: only admins can manage; everyone authed reads
DROP POLICY IF EXISTS "products insert authed" ON public.products;
DROP POLICY IF EXISTS "products update authed" ON public.products;
CREATE POLICY "products insert admin" ON public.products FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "products update admin" ON public.products FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(),'admin'))
  WITH CHECK (public.has_role(auth.uid(),'admin'));

-- Restrict direct execute on SECURITY DEFINER helpers (still usable via RLS/triggers)
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.apply_movement_to_stock() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
