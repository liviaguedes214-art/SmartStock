-- Corrige permissões usadas pelas políticas RLS e reforça a integridade do estoque.

-- A função has_role é usada nas políticas RLS. Usuários autenticados precisam
-- ter permissão de EXECUTE para que essas políticas possam ser avaliadas.
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;

-- Altera o papel em uma única transação e somente quando o solicitante é admin.
CREATE OR REPLACE FUNCTION public.set_user_role(target_user uuid, new_role public.app_role)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Apenas administradores podem alterar permissões.';
  END IF;

  IF target_user = auth.uid() THEN
    RAISE EXCEPTION 'Não é permitido alterar o próprio papel.';
  END IF;

  DELETE FROM public.user_roles WHERE user_id = target_user;
  INSERT INTO public.user_roles (user_id, role) VALUES (target_user, new_role);
END;
$$;

REVOKE ALL ON FUNCTION public.set_user_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.set_user_role(uuid, public.app_role) TO authenticated;

-- Impede registrar saídas ou perdas maiores que o estoque disponível.
-- O bloqueio da linha evita duas movimentações simultâneas ultrapassarem o saldo.
CREATE OR REPLACE FUNCTION public.validate_movement_stock()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  current_stock integer;
BEGIN
  IF NEW.type IN ('saida', 'perda') THEN
    SELECT quantity INTO current_stock
    FROM public.products
    WHERE id = NEW.product_id
    FOR UPDATE;

    IF current_stock IS NULL THEN
      RAISE EXCEPTION 'Produto não encontrado.';
    END IF;

    IF NEW.quantity > current_stock THEN
      RAISE EXCEPTION 'Estoque insuficiente. Disponível: %, solicitado: %.', current_stock, NEW.quantity;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_validate_movement_stock ON public.movements;
CREATE TRIGGER trg_validate_movement_stock
BEFORE INSERT ON public.movements
FOR EACH ROW EXECUTE FUNCTION public.validate_movement_stock();
